using System;
using Microsoft.AspNetCore.Identity.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore;
using NexaWork.Authentication.Data.Entities;

namespace NexaWork.Authentication.Data;

public class NexaWorkAuthDbContext : IdentityDbContext<NexaWorkUser, NexaWorkRole, string>
{
    public NexaWorkAuthDbContext(DbContextOptions<NexaWorkAuthDbContext> options) : base(options) { }

    protected override void OnModelCreating(ModelBuilder builder)
    {
        base.OnModelCreating(builder);

        

        builder.Entity<NexaWorkRole>(entity =>
        {
            entity.Property(e => e.Description).HasMaxLength(255);
        });

        // Keep the OpenIddict integration
        builder.UseOpenIddict(); 
    }

    protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
    {
        if (!optionsBuilder.IsConfigured)
        {
            var connectionString = "Server= localhost, 1433; Database=NexaWorkAuthenticationDb; User Id=sa; password=Dai@2018; TrustServerCertificate=True; Trusted_Connection=False; MultipleActiveResultSets=true;";
            optionsBuilder.UseSqlServer(connectionString);
        }
    }
}
