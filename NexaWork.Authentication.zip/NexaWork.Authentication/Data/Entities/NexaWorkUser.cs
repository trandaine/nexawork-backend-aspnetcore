using System;
using Microsoft.AspNetCore.Identity;

namespace NexaWork.Authentication.Data.Entities;

public class NexaWorkUser : IdentityUser
{
    
    public DateTime CreatedAt { get; set; } = DateTime.UtcNow;
}
