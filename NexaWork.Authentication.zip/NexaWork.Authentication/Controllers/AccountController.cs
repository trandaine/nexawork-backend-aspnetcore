using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Identity.Data;
using Microsoft.AspNetCore.Mvc;
using NexaWork.Authentication.Data.Entities;
using NexaWork.Authentication.DTOs;

namespace NexaWork.Authentication.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class AccountController : ControllerBase
    {
        private readonly UserManager<NexaWorkUser> _userManager;
        private readonly SignInManager<NexaWorkUser> _signInManager;

        public AccountController(UserManager<NexaWorkUser> userManager, SignInManager<NexaWorkUser> signInManager)
        {
            _userManager = userManager;
            _signInManager = signInManager;
        }



        

        [HttpPost("register")]
        public async Task<IActionResult> Register([FromBody] RegisterDTO registerDTO)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var user = new NexaWorkUser
            {
                UserName = registerDTO.Email,
                Email = registerDTO.Email,
                // FullName = registerDTO.FullName
            };

            var result = await _userManager.CreateAsync(user, registerDTO.Password);

            if (result.Succeeded)
            {
                // Automatically assign new users the Employee role
                await _userManager.AddToRoleAsync(user, "User");
                return Ok(new { Message = "User registered successfully." });
            }

            return BadRequest(result.Errors);
        }




        [HttpPost("login")]
        public async Task<IActionResult> Login([FromBody] LoginDTO loginDTO)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            // This method validates the password and sets an encrypted HTTP-only cookie
            var result = await _signInManager.PasswordSignInAsync(
                loginDTO.Email,
                loginDTO.Password,
                isPersistent: false,
                lockoutOnFailure: false);

            if (result.Succeeded)
            {
                return Ok(new { Message = "Login successful. Identity cookie established." });
            }

            return Unauthorized(new { Message = "Invalid credentials." });
        }




        [HttpPost("forgot-password")]
        public async Task<IActionResult> ForgotPassword([FromBody] ForgotPasswordDTO request)
        {
            if (!ModelState.IsValid) return BadRequest(ModelState);

            var user = await _userManager.FindByEmailAsync(request.Email);
            if (user == null || !(await _userManager.IsEmailConfirmedAsync(user)))
            {
                // Về mặt bảo mật, luôn trả về status thành công (Ok) để tránh việc 
                // Hacker dùng endpoint này để dò tìm xem email nào tồn tại trong hệ thống.
                return Ok(new { Message = "If that email address is in our database, we will send you an email to reset your password." });
            }

            // Sinh ra mã Token dùng một lần để reset password
            var token = await _userManager.GeneratePasswordResetTokenAsync(user);

            // TODO: Tích hợp thư viện gửi mail (như MailKit, SendGrid) ở đây
            // Ví dụ URL gửi đi: http://localhost:5173/reset-password?email=admin@nexawork.com&token=...

            // Tạm thời in ra Console để bạn copy và test API đổi mật khẩu sau này
            Console.WriteLine($"[EMAIL MOCK] Vui lòng gửi link này cho user: Reset Token của bạn là: {token}");

            return Ok(new { Message = "If that email address is in our database, we will send you an email to reset your password." });
        }
    }
}
