using System;

namespace NexaWork.Authentication.DTOs;

public class RegisterDTO
{
    public required string Email { get; set; }
    public required string Password { get; set; }
}
