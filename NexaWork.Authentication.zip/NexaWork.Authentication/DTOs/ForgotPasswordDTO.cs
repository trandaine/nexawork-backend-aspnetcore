using System;

namespace NexaWork.Authentication.DTOs;

public class ForgotPasswordDTO
{
    public required string Email { get; set; }
}
